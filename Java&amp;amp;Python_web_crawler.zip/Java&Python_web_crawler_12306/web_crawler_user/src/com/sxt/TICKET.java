package com.sxt;

public class TICKET {
    public String number;
    public String start;
    public String end;
    public String start_time;
    public String end_time;
    public String spend_time;
    public String state;
    public String[]seat;
    TICKET()
    {
        number=new String("");
        start=new String("");
        end=new String("");
        start_time=new String("");
        end_time=new String("");
        spend_time=new String("");
        state=new String("");
        seat=new String[11];
    }



}